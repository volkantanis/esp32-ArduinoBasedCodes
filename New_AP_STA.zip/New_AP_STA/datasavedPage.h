const char dataSaved_page[] PROGMEM = R"====(
<!DOCTYPE HTML>
<html>
<head> <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body bgcolor = "lightgrey">
<center>
<h1>Configuration Saved Successfully</h1><br>
<form align="center" action="/">
    <br><br><input type="submit" value="Return to config Menu Page">    
</form><br><br>
<form action="/close">
    <input type="submit" value="Close">
</form><br><br>

</html>
)====";
